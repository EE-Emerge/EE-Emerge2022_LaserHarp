//Necessary Libraries
#include <Bela.h>
#include <libraries/Scope/Scope.h>
#include <libraries/AudioFile/AudioFile.h>
#include <cmath>
#include <math.h>

//Wavetable Stuff
const int gWavetableLength = 44100;
const int gNumberOfSensors=7;
float gWavetable[gWavetableLength];							// Buffer that holds the wavetable
float gFloatPointers[gNumberOfSensors]={0,0,0,0,0,0,0};					// float position of the last frame played
int gIntPointers[gNumberOfSensors] = {0,0,0,0,0,0,0};					// Position of the last frame we played 
float gVolume=0.5;											// Global amplitude of the playback
float masterFrequencies[7]={16.35,18.35,20.6,21.83,24.5,27.5,30.87};							//starting frequency (C)

float frequency[gNumberOfSensors];

//Analog Input Stuff
int gAudioFramesPerAnalogFrame=2;							// holds how many analog frames per input frame
int gSensorInput[gNumberOfSensors]={0,1,2,3,4,5,6};						// records analog pins 1-8
float gSensorData[gNumberOfSensors]={0,0,0,0,0,0,0};						//hold the sensor data from all 8 pins
int gSensorIsTriggered[gNumberOfSensors];
int gNumberOfSensorsTriggered=0;
float gSensorLatency=10;											//ms of latency for the distance sensors
int framesSinceUpdate=0;

//Initialize the global oscilloScope
Scope gScope;

bool setup(BelaContext *context, void *userData)
{
	//Create Wavetable 
	/*
	for(unsigned int n = 0; n < gWavetableLength; n++) {
		//simple sine wave one (amplitude 1)
		float fundamental=sin(2.0*M_PI*float(n)/float(gWavetableLength));
		gWavetable[n] = fundamental;
	}
	*/
	for(unsigned int n = 0; n < gWavetableLength; n++) {
		//cool sine wave one
		
		float fundamental=0.2*sin(2.0*M_PI*float(n)/float(gWavetableLength));
		float harmonic1=0.7*sin(3.0*M_PI*float(n)/float(gWavetableLength));
		float harmonic2=0.1*sin(4.0*M_PI*float(n)/float(gWavetableLength));
		gWavetable[n] = fundamental+harmonic1+harmonic2;
	}
	
	//Analog Input Stuff
	// Check if analog channels are enabled
	if(context->analogFrames == 0 || context->analogFrames >= context->audioFrames) {
		rt_printf("Error: this example needs analog enabled, with 8 channels\n");
		return false;
	}
	
	//adjust octave
	int octave=4;
	for (int i=0; i<gNumberOfSensors; i++)
	{
		masterFrequencies[i]*=pow(2.0,octave);
	}

	// Initialise the Bela oscilloscope
	gScope.setup(1, context->audioSampleRate);
	return true;
}

void render(BelaContext *context, void *userData)
{
	for(unsigned int n = 0; n < context->audioFrames; n++) {
		
		//collect sensor data every 16 frames (collect values and number of sensors active)
		if(framesSinceUpdate<44100*gSensorLatency/1000.0)
		{
			framesSinceUpdate++;
		}
		else
		{
			
			for (unsigned int i=0; i<gNumberOfSensors; i++)
			{
				gSensorData[i]=analogRead(context, n/gAudioFramesPerAnalogFrame, gSensorInput[i]);		//collect sensor data
				if(gSensorData[i]>0.1)
				{
					gSensorIsTriggered[i]=1;														//track how many sensors are being triggered
				}
				else
				{
					gSensorIsTriggered[i]=0;
				}
				
			}
			framesSinceUpdate=0;
		}
		
		//set frequencies by observing sensor data
		for (int i=0; i<gNumberOfSensors; i++)
		{
			if (gSensorData[i]>=0.1 && gSensorData[i]<0.2)
			{
				frequency[i]=masterFrequencies[i];
			}
			
			if (gSensorData[i]>=0.2 && gSensorData[i]<0.5)
			{
				frequency[i]=masterFrequencies[i]*2.0;
			}
			if (gSensorData[i]>=0.5)
			{
				frequency[i]=masterFrequencies[i]*4.0;
			}
		}
		
		//compute output array
		float outputArray[gNumberOfSensors];
		for (int i=0; i<gNumberOfSensors; i++)
		{
			if (gSensorIsTriggered[i])
			{
				outputArray[i]=gWavetable[gIntPointers[i]];
			}
			else
			{
				outputArray[i]=0;
			}
		}
		
		//increment the read pointers and set to zero when they reach the end of the Wavetable
		for (int i=0; i<gNumberOfSensors; i++)
		{
			gFloatPointers[i]+=frequency[i]*float(gWavetableLength)/(float(context->audioSampleRate));
			if(gFloatPointers[i]>=float(gWavetableLength))
			{
				gFloatPointers[i]-=float(gWavetableLength);
			}
			gIntPointers[i]=int(gFloatPointers[i]);
			
		}
		
		//compute the final output float by summing and dividing by the number of triggered sensors
		float out=0;
		gNumberOfSensorsTriggered=0;
		for (int i=0; i<gNumberOfSensors; i++)
		{
			out+=outputArray[i];
			gNumberOfSensorsTriggered+=gSensorIsTriggered[i];
		}
		out = out/gNumberOfSensorsTriggered;
		
		//play the output
		for(unsigned int channel = 0; channel < context->audioOutChannels; channel++) {
			// Write the sample to every audio output channel
    		audioWrite(context, n, channel, gVolume*out);
    	}
    	
    	// Write the sample to the oscilloscope
    	gScope.log(out);
		
	}
}

void cleanup(BelaContext *context, void *userData)
{

}