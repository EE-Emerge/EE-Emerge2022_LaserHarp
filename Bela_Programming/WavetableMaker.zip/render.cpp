#include <Bela.h>
#include <libraries/Scope/Scope.h>
#include <cmath>
#include <math.h>

const int wavetableLength = 44100;		//default sample rate, plenty long for a 
float wavetable[wavetableLength];		// Buffer that holds the wavetable
float floatPointer=0.0;					//Position of the last frame played
int readPointer = 0;					//int of pointer

float globalVolume=0.1;					//global volume adjust, 1 is max

const float masterFrequency=16.35;		//frequency of lowest musical note, C0
int octave=3;							//change this to change the octave of the playback
float frequency = masterFrequency*pow(2,octave);		//float to keep track of changing frequency, if applicable

Scope gScope;






bool setup(BelaContext *context, void *userData)
{
	//simple sine wavetable
	/*
	for(unsigned int n = 0; n < wavetableLength; n++) {
		float fundamental=sin(2.0*M_PI*float(n)/float(wavetableLength));
		wavetable[n]=fundamental;
	}
	*/
	
	//complex sine wavetable
	/*
	for(unsigned int n = 0; n < wavetableLength; n++) {
		float fundamental=0.25*sin(2.0*M_PI*float(n)/float(wavetableLength));
		float harmonic1=0.5*sin(2.0*2.0*M_PI*float(n)/float(wavetableLength));
		float harmonic2=0.25*sin(4.0*2.0*M_PI*float(n)/float(wavetableLength));
		wavetable[n]=fundamental+harmonic1+harmonic2;
	}
	*/
	
	// Initialise the Bela oscilloscope
	gScope.setup(1, context->audioSampleRate);
	return true;
}





void render(BelaContext *context, void *userData)
{
	
	for(unsigned int n = 0; n < context->audioFrames; n++) {
		//writes part of the wavetable to the output float
	    float out = wavetable[readPointer];
	    // Increment read pointer and reset to 0 when end of table is reached
	    floatPointer+=frequency*float(wavetableLength)/(float(context->audioSampleRate));
	    if(floatPointer>=float(wavetableLength))
	    {
	    	//set the pointer back to the beginning of the sample
	    	floatPointer-=float(wavetableLength);
	    	
	    }
	    //set the read pointer to an int
	     readPointer=int(floatPointer);
	        
		for(unsigned int channel = 0; channel < context->audioOutChannels; channel++) {
			// Write the sample to every audio output channel
			audioWrite(context, n, channel, globalVolume*out);
		}
		// Write the sample to the oscilloscope
    	gScope.log(out);
	}
}

void cleanup(BelaContext *context, void *userData)
{

}